process.env.DB_SERVER   = 'localhost'; 
process.env.DB_USER     = 'root'     ;
process.env.DB_PASS     = 'root' ;
process.env.DB_DATABASE = 'maria' ;