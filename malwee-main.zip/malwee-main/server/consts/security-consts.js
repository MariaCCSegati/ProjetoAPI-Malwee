exports.USER_TYPE_PUBLIC  = 0;
exports.USER_TYPE_PRIVATE = 1;

exports.PASSWORD_SALT = 'SFAAFsd3gkunffohtyh2o9%3238¨%vsujbsyvar';
exports.JWT_KEY       = 'fkjnion2h7usaklxue¨¨$#*safghasd5828asd2';